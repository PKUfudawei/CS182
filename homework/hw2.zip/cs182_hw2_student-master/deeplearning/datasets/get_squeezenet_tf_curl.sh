curl -OL "http://www.cs.berkeley.edu/~jfc/squeezenet_tf.zip"
unzip squeezenet_tf.zip
rm squeezenet_tf.zip
